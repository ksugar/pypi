from __future__ import absolute_import, print_function
from setuptools import setup, find_packages
from os import path


# ------------------------------------------------------------------------------------

# https://stackoverflow.com/a/22866630
# python setup.py sdist                    ->  __file__ is relative path
# python /absolute/path/to/setup.py sdist  ->  __file__ is absolute path
# python -m build --sdist                  ->  __file__ is absolute path

# cf. https://github.com/mkleehammer/pyodbc/issues/82#issuecomment-231561240
# _dir = path.dirname(__file__)
_dir = ""  #  assumption: Path(__file__).parent == Path.cwd()

with open(path.join(_dir, "pytorch_stardist", "version.py"), encoding="utf-8") as f:
    exec(f.read())

with open(path.join(_dir, "README.md"), encoding="utf-8") as f:
    long_description = f.read()


setup(
    name="pytorch-stardist",
    version=__version__,
    description="PyTorch StarDist - PyTorch implementation of StarDist",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ksugar/pytorch-stardist",
    author="Ko Sugawara",
    author_email="ko.sugawara@riken.jp",
    license="BSD-3-Clause",
    packages=["pytorch_stardist"],
    python_requires=">=3.6",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering",
        "License :: OSI Approved :: BSD License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    install_requires=[
        "gputools==0.2.13",
        "numpy==1.23.1",
        "stardist>=0.8.5",
        "torch>=2.0.1",
        "torchvision>=0.15.2",
        "pandas>=1.1.3",
    ],
)
